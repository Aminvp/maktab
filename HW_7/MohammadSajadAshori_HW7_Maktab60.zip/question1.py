class Insufficient(Exception):
    pass

class Account:
    min_balance = 10 #unit : $
    def __init__(self, owner:str, initial_balance:int):
        self.owner = owner
        self.balance = initial_balance
    
    def withdraw(self, amount):
        try:
            self.balance -= self.__valid_withdraw(amount)
        except Insufficient:
            self.show_message('insufficient', amount)
        else:
            self.show_message('withdraw', amount)
            
                    
    def deposite(self, amount):
        self.balance += amount
        self.show_message('deposite', amount)
    
    def transfer(self, other, amount):
        try:
            self.balance -= self.__valid_withdraw(amount)
        except Insufficient:
            self.show_message('insufficient', amount)
        else:
            other.balance += amount
            self.show_message('transfer', amount, other)      
            
    def __valid_withdraw(self, amount):
        #it is said in question:use a private method, i don't get clearly what it means, so i used __ to private it :)
        if self.balance - amount >= self.min_balance:
            #using self.min_balance instead of Account.min_balance is because maybe min_balance be changed only for specific account
            return amount
        else:
            raise Insufficient
    
    def show_message(self, operation, amount, other=None):
        '''this method is just for clean code in showing messages... '''
        if operation == 'withdraw':
            print(f'\nWithdrawal Was Successful.\nAccount Owner : {self.owner}\nWithdraw Amount : {amount}$\nCurrent Balance : {self.balance}$\n')
        elif operation == 'deposite':
            print(f'\nDeposite Was Successful.\nAccount Owner : {self.owner}\nDeposite Amount : {amount}$\nCurrent Balance : {self.balance}$\n') 
        elif operation == 'transfer':
            print(f'\nTrasnfer Was Successful.\nFrom : {self.owner}\nTo : {other.owner}\nAmount : {amount}$\nCurrent Balance : {self.balance}$\n')
        elif operation =='insufficient':
            print(f'\nBalance is not Enough!\nAt least balance is {self.min_balance}$\n')
     
if __name__ == '__main__':
    account1 = Account('sajad', 100)
    account2 = Account('anonymous', 500)
    account1.withdraw(20)
    account2.deposite(30)
    print(f'account1 balance : {account1.balance}$')
    print(f'account2 balance : {account2.balance}$')
    # account1.min_balance = 5 #test for comment description of __valid_withdraw
    account1.transfer(account2, 69)
    print(f'account1 balance : {account1.balance}$')
    print(f'account2 balance : {account2.balance}$')
    