from question1 import Account




account1 = Account('sajad', 100)
account2 = Account('anonymous', 500)
account1.withdraw(20)
account2.deposite(30)
print(f'account1 balance : {account1.balance}$')
print(f'account2 balance : {account2.balance}$')
# account1.min_balance = 5 #test for comment description of __valid_withdraw
account1.transfer(account2, 100)
print(f'account1 balance : {account1.balance}$')
print(f'account2 balance : {account2.balance}$')